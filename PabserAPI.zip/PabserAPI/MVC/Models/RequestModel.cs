﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class RequestModel
    {
        [Display(Name ="Booking ID")]
        public int IdBooking { get; set; }

        [Display(Name ="Id Ruangan")]
        public int IdRoom { get; set; }
        
        
        [Display(Name ="Nama Ruangan")]
        public string RoomName { get; set; }

        public int Status { get; set; }

        
    }
}