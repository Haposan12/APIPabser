﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class FasilitasModel
    {
        public int IDFasilitas { get; set; }
        [DisplayName("ID Ruangan")]
        public int IDRuangan { get; set; }

        [DisplayName("Nama Fasilitas")]
        public string NamaFasilitas { get; set; }
        public string Kondisi { get; set; }
    }
}