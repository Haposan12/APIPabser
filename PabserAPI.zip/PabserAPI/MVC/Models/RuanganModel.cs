﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class RuanganModel
    {
        public int IDRuangan { get; set; }
        [Required(ErrorMessage ="This field is required")]
        [Display(Name = "Nama Ruangan")]
        public string NamaRuangan { get; set; }

        [Display(Name ="Kapasitas Ruangan")]
        public int KapasitasRuangan { get; set; }
        [Display(Name = "Status")]
        public int StatusRuangan { get; set; }

        [DataType(DataType.Date)]
        [Display(Name ="Tanggal Available")]
        public System.DateTime TanggalAvailable { get; set; }
    }
}