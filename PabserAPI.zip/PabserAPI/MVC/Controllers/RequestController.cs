﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC.Models;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace MVC.Controllers
{
    public class RequestController : Controller
    {
        string baseUrl = "http://localhost:8181/api/";
        // GET: Request
        public async Task<ActionResult> Index()
        {
            IEnumerable<RequestModel> req;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage res = await client.GetAsync("booking/lists");
                if (res.IsSuccessStatusCode)
                {
                    req = res.Content.ReadAsAsync<IEnumerable<RequestModel>>().Result;
                    return View(req);
                }
                return View("error");   
            }
        }

      

        
        public ActionResult Add(RequestModel request)
        {
            
                HttpResponseMessage response = GlobalVariable.WebApiClient.PostAsJsonAsync("Request", request).Result;
                TempData["SuccessMessage"] = "Saved Successfully";
            
           

            return RedirectToAction("Index");
        }



    }
}