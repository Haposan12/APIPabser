﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC.Models;
using System.Net.Http;

namespace MVC.Controllers
{
    public class RuanganController : Controller
    {
        // GET: Ruangan
        public ActionResult Index()
        {
            IEnumerable<RuanganModel> ruanganList;
            HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("Ruangan").Result;
            ruanganList = response.Content.ReadAsAsync<IEnumerable<RuanganModel>>().Result;

            return View(ruanganList);
        }

        public ActionResult AddOrEdit(int id=0)
        {
            if(id == 0)
                return View(new RuanganModel());
            else
            {
                HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("Ruangan/"+id.ToString()).Result;
                return View(response.Content.ReadAsAsync<RuanganModel>().Result);
            }
        }

        [HttpPost]
        public ActionResult AddOrEdit(RuanganModel ruangan)
        {
            if(ruangan.IDRuangan == 0) {
                HttpResponseMessage response = GlobalVariable.WebApiClient.PostAsJsonAsync("Ruangan", ruangan).Result;
                TempData["SuccessMessage"] = "Saved Successfully";
            }
            else
            {
                HttpResponseMessage response = GlobalVariable.WebApiClient.PutAsJsonAsync("Ruangan/"+ruangan.IDRuangan, ruangan).Result;
                TempData["SuccessMessage"] = "Updated Successfully";
            }
           
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = GlobalVariable.WebApiClient.DeleteAsync("Ruangan/" + id.ToString()).Result;
            TempData["SuccessMessage"] = "Deleted SuccessFully";
            return RedirectToAction("Index");
        }
    }
}