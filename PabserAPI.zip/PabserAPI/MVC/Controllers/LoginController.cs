﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC.Models;

namespace MVC.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Authorize(MVC.Models.User user)
        {
            using(Entities db = new Entities())
            {
                var userDetails = db.Users.Where(x => x.NamaUser == user.NamaUser && x.Password == user.Password).FirstOrDefault();

                if(userDetails == null)
                {
                    user.LoginErrorMessage = "Wrong username or password";
                    return View("Index", user);
                }
                else
                {
                    Session["userID"] = userDetails.IDUser;
                    Session["userName"] = userDetails.NamaUser;
                    return RedirectToAction("Index", "Ruangan");
                }
            }
        }

        public ActionResult LogOut()
        {
            int userID = (int)Session["userID"];
            Session.Abandon();
            return RedirectToAction("Index", "Login");
        }

    }
}