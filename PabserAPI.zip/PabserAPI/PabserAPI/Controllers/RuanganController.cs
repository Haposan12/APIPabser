﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using PabserAPI.Models;

namespace PabserAPI.Controllers
{
    public class RuanganController : ApiController
    {
        private APIEntities db = new APIEntities();

        // GET: api/Ruangan
        public IQueryable<Ruangan> GetRuangans()
        {
            return db.Ruangans;
        }

        // GET: api/Ruangan/5
        [ResponseType(typeof(Ruangan))]
        public IHttpActionResult GetRuangan(int id)
        {
            Ruangan ruangan = db.Ruangans.Find(id);
            if (ruangan == null)
            {
                return NotFound();
            }

            return Ok(ruangan);
        }

        [Route("api/Ruangan/{date}")]
        [ResponseType(typeof(Ruangan))]
        [HttpGet]
        public IHttpActionResult GetRuanganByDate(DateTime date)
        {
            DateTime dateA = Convert.ToDateTime("2019-05-09");
            var ruangan = db.Ruangans.Where(x => x.TanggalAvailable == date).ToList();

            return Ok(ruangan);
        }

        // PUT: api/Ruangan/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRuangan(int id, Ruangan ruangan)
        {
            

            if (id != ruangan.IDRuangan)
            {
                return BadRequest();
            }

            db.Entry(ruangan).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RuanganExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Ruangan
        [ResponseType(typeof(Ruangan))]
        public IHttpActionResult PostRuangan(Ruangan ruangan)
        {
            

            db.Ruangans.Add(ruangan);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = ruangan.IDRuangan }, ruangan);
        }

        // DELETE: api/Ruangan/5
        [ResponseType(typeof(Ruangan))]
        public IHttpActionResult DeleteRuangan(int id)
        {
            Ruangan ruangan = db.Ruangans.Find(id);
            if (ruangan == null)
            {
                return NotFound();
            }

            db.Ruangans.Remove(ruangan);
            db.SaveChanges();

            return Ok(ruangan);
        }

            

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RuanganExists(int id)
        {
            return db.Ruangans.Count(e => e.IDRuangan == id) > 0;
        }
    }
}